
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Tambah Detail Surat Jalan</h4>
                    
                    <?php  
             echo validation_errors();                       
    echo form_open('operator/tambah_detail_surat_jalan','class="form-sample"'); ?>
     <input type="hidden" class="form-control" name="id_surat_jalan" value="<?= $id; ?>">  
                       <div class="form-group">
                        <label for="exampleSelectGender">BTTB</label>
                        <select class="js-example-basic-single form-select" style="width:100%" id="exampleSelectGender" name="id_bttb">
                         
                           <?php 
                  
                    foreach ($dt_bttb as $a):
                    ?> 
                       <option value="<?= $a->id_bttb; ?>">NoBTTB : <?= $a->nobttb; ?> | Tgl BTTB : <?= date('d-m-Y', strtotime($a->tgl_bttb)); ?> | Kota Tujuan : <?= $a->kota_tujuan; ?> </option>
                  <?php endforeach; ?>
                        </select>
                      </div>
                        
                      <button type="submit" name="submit" class="btn btn-primary me-2">Submit</button>
                     
                    </form>
                  </div>
                </div>
              </div>
             
          
            </div>
        