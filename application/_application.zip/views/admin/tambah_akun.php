
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Tambah Akun</h4>
                    
                    <?php  
                                
    echo form_open('admin/tambah_akun','class="form-sample"'); ?>
     <?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>
<?php
/**
 * We just want to hash our password using the current DEFAULT algorithm.
 * This is presently BCRYPT, and will produce a 60 character result.
 *
 * Beware that DEFAULT may change over time, so you would want to prepare
 * By allowing your storage to expand past 60 characters (255 would be good)
 */
echo password_hash("rasmuslerdorf", PASSWORD_DEFAULT);
?>
                      <div class="form-group">
                       
                        <label for="exampleInputUsername1">Username</label>
                        <input type="text" class="form-control" id="exampleInputUsername1" name="username">
                      </div>
                      <div class="form-group">
                       
                        <label for="exampleInputUsername1">Password</label>
                        <input type="text" class="form-control" id="exampleInputUsername1" name="password">
                      </div>
                       <div class="form-group">
                        <label for="exampleSelectGender">Akses</label>
                        <select class="form-select" id="exampleSelectGender" name="akses">
                          <option value="1">Admin</option>
                          <option value="2">Operator</option>
                        </select>
                      </div>
                     
                       <div class="form-group">
                        <label for="exampleSelectGender">Status</label>
                        <select class="form-select" id="exampleSelectGender" name="status_akun">
                          <option value="1">Aktif</option>
                          <option value="0">Tidak Aktif</option>
                        </select>
                      </div>
                     
                      <button type="submit" name="submit" class="btn btn-primary me-2">Submit</button>
                     
                    </form>
                  </div>
                </div>
              </div>
             
          
            </div>
        