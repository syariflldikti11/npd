<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="<?= base_url('mycontroller/send_pts');?>"> Kirim PT</a> <br />
<a href="<?= base_url('mycontroller/send_prodi');?>"> Kirim Prodi</a> <br />
<a href="<?= base_url('mycontroller/send_mhs_masuk');?>"> Kirim Mhs Masuk</a> <br />
<a href="<?= base_url('mycontroller/send_mhs_keluar');?>"> Kirim Mhs Keluar</a> <br />
<a href="<?= base_url('mycontroller/send_pelaporan_pt');?>"> Kirim Pelaporan PT</a> <br />
<a href="<?= base_url('mycontroller/send_dosen');?>"> Kirim Dosen</a> <br />
</body>
</html>